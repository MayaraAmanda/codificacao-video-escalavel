
#include "H264AVCCommonLib.h"
#include "H264AVCCommonLib/Quantizer.h"

H264AVC_NAMESPACE_BEGIN

Quantizer::Quantizer()
{
}

Quantizer::~Quantizer()
{
}


H264AVC_NAMESPACE_END
